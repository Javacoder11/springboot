package com.example.demo.repository;

import org.springframework.stereotype.Repository;

@Repository
public class GreetingRepository {
    // Dummy repository
}