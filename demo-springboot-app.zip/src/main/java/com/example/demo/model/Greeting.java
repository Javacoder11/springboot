package com.example.demo.model;

public class Greeting {
    private Long id;
    private String message;

    // Getters and Setters
}